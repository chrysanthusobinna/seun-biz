
<?php $__env->startSection('title', 'Bus/Car Rent Service | SEUN LAFE MULTIBIZ'); ?>
<?php $__env->startSection('content'); ?>


<!-- Start main-content -->
<section class="page-title" style="background-image: url(/images/background/page-title.jpg);">
    <div class="auto-container">
        <div class="title-outer">
            <h1 class="title">Bus/Car Rent Service</h1>
            <ul class="page-breadcrumb">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li>Services</li>
            </ul>
        </div>
    </div>
</section>
<!-- end main-content -->


<!--Start Services Details-->
<section class="services-details">
	<div class="container">
		<div class="row">

			<!--Start Services Details Content-->
			<div class="col-xl-8 col-lg-8">
				<div class="services-details__content">
					<img src="/images/resource/p-11.jpg" alt="Bus/Car Rent Service" />
					<h2 class="mt-4">Professional Bus & Car Rental Solutions</h2>
					<p>At <strong>SEUN LAFE MULTIBIZ</strong>, we offer reliable and flexible <strong>Bus and Car Rental Services</strong> tailored to your personal, corporate, or group transport needs. Whether you require a vehicle for business trips, events, tours, or daily commuting, our fleet is maintained to the highest standards for your comfort and safety.</p>
					<ul>
						<li>Wide range of vehicles: sedans, SUVs, buses, and luxury cars</li>
						<li>Professional drivers and self-drive options</li>
						<li>Short-term and long-term rental packages</li>
						<li>Airport transfers, group tours, and corporate transport</li>
						<li>Transparent pricing and excellent customer support</li>
					</ul>
					<p>Backed by years of experience in general merchandise and logistics, SEUN LAFE MULTIBIZ ensures every journey is smooth and stress-free. We are dedicated to delivering value, safety, and convenience—helping you focus on what matters most.</p>
					<p>Ready to book a vehicle or need a custom transport solution? <a href="<?php echo e(route('contact')); ?>" >Contact us here</a> and our team will be happy to assist you.</p>
				</div>
			</div>
			<!--End Services Details Content-->
            
			<!--Start Services Details Sidebar-->
			<div class="col-xl-4 col-lg-4">
				<div class="service-sidebar">
					<!--Start Services Details Sidebar Single-->
					<div class="sidebar-widget service-sidebar-single">
						<div class="service-sidebar wow fadeInUp"
							data-wow-delay="0.1s" data-wow-duration="1200m">
							<div class="service-list">
							<ul>
							<li><a href="<?php echo e(route('services.general-merchandise')); ?>" class="<?php echo e(request()->routeIs('services.general-merchandise') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>General Merchandise</span></a></li>
							<li><a href="<?php echo e(route('services.ticketing-reservation')); ?>" class="<?php echo e(request()->routeIs('services.ticketing-reservation') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Ticketing & Reservation</span></a></li>
							<li><a href="<?php echo e(route('services.travel-tour-services')); ?>" class="<?php echo e(request()->routeIs('services.travel-tour-services') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Travel Tour Services</span></a></li>
							<li><a href="<?php echo e(route('services.student-school-loan')); ?>" class="<?php echo e(request()->routeIs('services.student-school-loan') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Student School Loan</span></a></li>
							<li><a href="<?php echo e(route('services.hotel-reservations')); ?>" class="<?php echo e(request()->routeIs('services.hotel-reservations') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Hotel Reservations</span></a></li>
							<li><a href="<?php echo e(route('services.airport-transfers')); ?>" class="<?php echo e(request()->routeIs('services.airport-transfers') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Airport Transfers</span></a></li>
							<li><a href="<?php echo e(route('services.travel-health-insurance')); ?>" class="<?php echo e(request()->routeIs('services.travel-health-insurance') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Travel & Health Insurance</span></a></li>
							<li><a href="<?php echo e(route('services.cargo-shipping')); ?>" class="<?php echo e(request()->routeIs('services.cargo-shipping') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Cargo and Shipping</span></a></li>
							<li><a href="<?php echo e(route('services.immigration-protocol')); ?>" class="<?php echo e(request()->routeIs('services.immigration-protocol') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Immigration & Protocol</span></a></li>
							<li><a href="<?php echo e(route('services.visa-counselling-support')); ?>" class="<?php echo e(request()->routeIs('services.visa-counselling-support') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Visa Counselling Support Services</span></a></li>
							<li><a href="<?php echo e(route('services.bus-car-rent-service')); ?>" class="<?php echo e(request()->routeIs('services.bus-car-rent-service') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Bus/ Car Rent Service</span></a></li>
							<li><a href="<?php echo e(route('services.medical-health-tourism')); ?>" class="<?php echo e(request()->routeIs('services.medical-health-tourism') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Medical Health Tourism</span></a></li>
							<li><a href="<?php echo e(route('services.chartered-aircraft-service')); ?>" class="<?php echo e(request()->routeIs('services.chartered-aircraft-service') ? 'current' : ''); ?>"><i class="fas fa-angle-right"></i><span>Chartered Aircraft Service</span></a></li>
							</ul>
							</div>
						</div>
					</div>

 
 
				</div>
			</div>
			<!--End Services Details Sidebar-->


		</div>
	</div>
</section>
<!--End Services Details-->

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\seun-biz\resources\views/bus-car-rent-service.blade.php ENDPATH**/ ?>