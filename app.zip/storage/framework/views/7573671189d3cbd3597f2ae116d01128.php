<p><strong>Name:</strong> <?php echo e($data['form_name']); ?></p>
<p><strong>Email:</strong> <?php echo e($data['form_email']); ?></p>
<?php if(!empty($data['form_phone'])): ?>
<p><strong>Phone:</strong> <?php echo e($data['form_phone']); ?></p>
<?php endif; ?>
<?php if(!empty($data['form_subject'])): ?>
<p><strong>Subject:</strong> <?php echo e($data['form_subject']); ?></p>
<?php endif; ?>
<p><strong>Message:</strong></p>
<p><?php echo e($data['form_message']); ?></p><?php /**PATH C:\Users\user\Desktop\seun-biz\resources\views/emails/contact-form.blade.php ENDPATH**/ ?>